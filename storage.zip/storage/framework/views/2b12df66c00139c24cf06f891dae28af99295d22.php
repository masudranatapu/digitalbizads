

<?php $__env->startSection('content'); ?>
<section>
    <div class="flex flex-wrap">
        <div class="pt-6 lg:pt-16 pb-6 w-full lg:w-full mt-48">
            <div class="max-w-md mx-auto">
                <div>
                    <div class="mb-6 px-3 text-center">
                        <span class="text-gray-500"><?php echo e(__('500')); ?></span>
                        <h3 class="text-2xl font-bold mb-5"><?php echo e(__('Internal Server Error')); ?></h3>
                        <a class="mb-6 w-full p-4 bg-blue-600 hover:bg-blue-700 rounded text-sm font-bold text-gray-50 transition duration-200"
                            href="<?php echo e(url('/')); ?>"><?php echo e(__('Back to home')); ?></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', ['nav' => false, 'banner' => false, 'footer' => false, 'cookie' => false, 'setting' => false, 'title' => true, 'title' => __('500 - Internal Server Error')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webdevs\digitalbizads\resources\views/errors/500.blade.php ENDPATH**/ ?>