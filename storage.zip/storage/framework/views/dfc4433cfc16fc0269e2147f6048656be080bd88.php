<footer class="bg-gray-800 pt-10 sm:mt-10 pt-10">
    <div class="max-w-6xl m-auto text-gray-800 flex flex-wrap justify-left">
        <!-- Col-1 -->
        <div class="p-5 w-1/2 sm:w-4/12 <?php echo e($supportPage[1]->section_content || $supportPage[2]->section_content || $supportPage[3]->section_content || $supportPage[4]->section_content != '' ? 'md:w-3/12' : 'md:w-4/12'); ?>">
            <!-- Col Title -->
            <div class="text-xs uppercase text-gray-400 font-medium mb-6">
                <?php echo e(__('Getting Started')); ?>

            </div>

            <!-- Links -->
            <?php if(request()->is('/') != false): ?>
            <a href="#how-it-works"
                class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('How it works?')); ?>

            </a>
            <?php else: ?>
            <a href="<?php echo e(route('home-locale')); ?>#how-it-works"
                class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('How it works?')); ?>

            </a>
            <?php endif; ?>

            <?php if(request()->is('/') != false): ?>
            <a href="#features" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Features')); ?>

            </a>
            <?php else: ?>
            <a href="<?php echo e(route('home-locale')); ?>#features" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Features')); ?>

            </a>
            <?php endif; ?>

            <?php if(request()->is('/') != false): ?>
            <a href="#pricing" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Pricing')); ?>

            </a>
            <?php else: ?>
            <a href="<?php echo e(route('home-locale')); ?>#pricing" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Pricing')); ?>

            </a>
            <?php endif; ?>

            <a href="<?php echo e(route('faq')); ?>" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('FAQs')); ?>

            </a>

        </div>

        <!-- Col-2 -->
        <div class="p-5 w-1/2 sm:w-4/12 <?php echo e($supportPage[1]->section_content || $supportPage[2]->section_content || $supportPage[3]->section_content || $supportPage[4]->section_content != '' ? 'md:w-3/12' : 'md:w-4/12'); ?>">
            <!-- Col Title -->
            <div class="text-xs uppercase text-gray-400 font-medium mb-6">
                <?php echo e(__('My Account')); ?>

            </div>

            <!-- Links -->
            <a href="<?php echo e(route('login')); ?>"
                class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Login')); ?>

            </a>
            <a href="<?php echo e(route('register')); ?>"
                class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Register')); ?>

            </a>
        </div>

        <!-- Col-3 -->
        <div class="p-5 w-1/2 sm:w-4/12 <?php echo e($supportPage[1]->section_content || $supportPage[2]->section_content || $supportPage[3]->section_content || $supportPage[4]->section_content != '' ? 'md:w-3/12' : 'md:w-4/12'); ?>">
            <!-- Col Title -->
            <div class="text-xs uppercase text-gray-400 font-medium mb-6">
                <?php echo e(__('Helpful Links')); ?>

            </div>

            <!-- Links -->
            <a href="<?php echo e(route('refund.policy')); ?>" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Refund Policy')); ?>

            </a>
            <a href="mailto:<?php echo e($supportPage[0]->section_content); ?>" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Support')); ?>

            </a>
            <a href="<?php echo e(route('privacy.policy')); ?>" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Privacy Policy')); ?>

            </a>
            <a href="<?php echo e(route('terms.and.conditions')); ?>" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Terms and Conditions')); ?>

            </a>
        </div>

        <?php if($supportPage[1]->section_content || $supportPage[2]->section_content || $supportPage[3]->section_content || $supportPage[4]->section_content != ""): ?>
        <!-- Col-3 -->
        <div class="p-5 w-1/2 sm:w-4/12 md:w-3/12">
            <!-- Col Title -->
            <div class="text-xs uppercase text-gray-400 font-medium mb-6">
                <?php echo e(__('Social Links')); ?>

            </div>

            <!-- Links -->
            <?php if($supportPage[1]->section_content != ""): ?>
            <a href="<?php echo e($supportPage[1]->section_content); ?>" target="_blank" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Facebook')); ?>

            </a>
            <?php endif; ?>
            
            <?php if($supportPage[2]->section_content != ""): ?>
            <a href="<?php echo e($supportPage[2]->section_content); ?>" target="_blank" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Twitter')); ?>

            </a>
            <?php endif; ?>

            <?php if($supportPage[3]->section_content != ""): ?>
            <a href="<?php echo e($supportPage[3]->section_content); ?>" target="_blank" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('Instagram')); ?>

            </a>
            <?php endif; ?>

            <?php if($supportPage[4]->section_content != ""): ?>
            <a href="<?php echo e($supportPage[4]->section_content); ?>" target="_blank" class="my-3 block text-gray-300 hover:text-gray-100 text-lg font-medium duration-700">
                <?php echo e(__('LinkedIn')); ?>

            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="pt-2 pb-2">
        <div class="flex pb-5 px-3 m-auto pt-5
            border-t border-gray-500 text-gray-400 text-lg
            flex-col md:flex-row max-w-6xl">
            <div class="mt-2">
                <span id="year"></span> <?php echo e(config('app.name')); ?>. <?php echo e(__('All rights reserved.')); ?>

            </div>
        </div>
    </div>
</footer>
<?php /**PATH F:\xampp\htdocs\webdevs\digitalbizads\resources\views/web/footer.blade.php ENDPATH**/ ?>